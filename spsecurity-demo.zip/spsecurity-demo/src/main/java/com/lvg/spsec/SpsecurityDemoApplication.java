package com.lvg.spsec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpsecurityDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpsecurityDemoApplication.class, args);
	}

}
