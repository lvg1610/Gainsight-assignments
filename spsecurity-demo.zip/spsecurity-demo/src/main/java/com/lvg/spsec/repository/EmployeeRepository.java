package com.lvg.spsec.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.lvg.spsec.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Integer>
{

}
