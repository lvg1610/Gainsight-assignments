package com.lvg.spsec.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lvg.spsec.entity.Users;
import com.lvg.spsec.repository.UsersRepository;

@Service
public class UsersService
{
	@Autowired
	UsersRepository usersRepository;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Transactional
	public boolean addUsers(Users user)
	{
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		Users u = usersRepository.save(user);
		return u!=null;
	}

}
