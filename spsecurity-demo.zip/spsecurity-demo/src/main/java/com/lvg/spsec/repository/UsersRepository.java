package com.lvg.spsec.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.lvg.spsec.entity.Users;
import java.util.Optional;
public interface UsersRepository extends JpaRepository<Users,String>
{
    Optional<Users> findByUsernameAndPassword(String username,String password);
}
