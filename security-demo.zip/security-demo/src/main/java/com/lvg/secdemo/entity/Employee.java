package com.lvg.secdemo.entity;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Table(name="employee2")
@Entity
public class Employee 
{
    @Id
    @Column(name="emp_no")
    private int employeeNo;
    
    @Column(name="emp_name")
    private String employeeName;
    
    @Column(name="emp_sal")
    private double salary;
    
    @Column(name="deptno")
    private int departmentNo;
    
    public Employee() {}

	public Employee(int employeeNo, String employeeName, double salary, int departmentNo) 
	{
		this.employeeNo = employeeNo;		this.employeeName = employeeName;
		this.salary = salary;		this.departmentNo = departmentNo;
	}

	public int getEmployeeNo() {
		return employeeNo;
	}

	public void setEmployeeNo(int employeeNo) {
		this.employeeNo = employeeNo;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public int getDepartmentNo() {
		return departmentNo;
	}

	public void setDepartmentNo(int departmentNo) {
		this.departmentNo = departmentNo;
	}
    
}
