package com.lvg.secdemo.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.lvg.secdemo.entity.Employee;
import com.lvg.secdemo.service.EmployeeService;
@RequestMapping("/employee")
@RestController
public class EmployeeController 
{
     @Autowired
     EmployeeService employeeService;
     
 
     @GetMapping
     @PreAuthorize("hasAuthority('ROLE_ADMIN')")
     public ResponseEntity<List<Employee>> getAllEmployees()
     {
    	 return new ResponseEntity<List<Employee>>(employeeService.getAllEmployees(),HttpStatus.OK);
     }
     
     @GetMapping("/{employeeNo}")
     @PreAuthorize("hasAuthority('ROLE_USER')")
     public ResponseEntity<Employee> getEmployeeByNo(@PathVariable int employeeNo)
     {
    	 return new ResponseEntity<Employee>(employeeService.getEmployeeByNo(employeeNo),HttpStatus.OK);
     }
     
     @GetMapping("/showMessage")
     public String getWelcome()
     {
    	 return "Welcome to Spring Security";
     }
}
