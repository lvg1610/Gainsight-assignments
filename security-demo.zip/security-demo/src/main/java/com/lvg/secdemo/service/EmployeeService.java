package com.lvg.secdemo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lvg.secdemo.entity.Employee;
import com.lvg.secdemo.repository.EmployeeRepository;

@Service
public class EmployeeService 
{
    @Autowired
    EmployeeRepository employeeRepository;
    
    @Transactional(readOnly=true)
    public List<Employee> getAllEmployees()
    {
    	return employeeRepository.findAll();
    }
    
    @Transactional(readOnly=true)
    public Employee getEmployeeByNo(int employeeNo)
    {
    	Optional<Employee> oe = employeeRepository.findById(employeeNo);
    	if(oe.isPresent()) return oe.get();
    	throw new RuntimeException("Employee Does not Exist");
    }
}
